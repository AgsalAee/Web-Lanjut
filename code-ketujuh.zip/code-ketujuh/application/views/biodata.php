<html>
    <head>
        <style>
        </style>
        <title>BIODATA</title>
    </head>
    <body>    
    <table>
            <tr>
                <td colspan="3"><center><h1>Biodata</h1></center></td>
                
            </tr>
            <tr>
                <td rowspan="3"><img src="assets/images/logo.png" height=150 width=150 style=”float:left;”></td>
                <th>Nama : </th>
                <td>Septianda Reza Maulana</td>
            </tr>
            <tr>
                <th>Alamat : </th>
                <td>Jalan Kesumba No 2B</td>
            </tr>
            <tr>
                <th>No Telepon : </th> 
                <td>082257125415</td>
            </tr>
        </table>
    </body>
</html>